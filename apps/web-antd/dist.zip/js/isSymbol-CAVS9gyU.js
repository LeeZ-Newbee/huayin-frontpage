import{av as s,aH as t}from"./bootstrap-AhoI3cF7.js";var a="[object Symbol]";function e(o){return typeof o=="symbol"||s(o)&&t(o)==a}export{e as i};
