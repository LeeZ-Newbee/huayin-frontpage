import{P as o,aE as r}from"../jse/index-index-BuhP3T1S.js";const f=()=>{const e=o(new Map),s=a=>t=>{e.value.set(a,t)};return r(()=>{e.value=new Map}),[s,e]};export{f as u};
